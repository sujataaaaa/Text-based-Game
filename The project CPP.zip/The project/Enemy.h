//
// Created by SUTI0007 on 2026-03-18.
//

#ifndef ENEMY_H
#define ENEMY_H
#include<string>
#include<random>

using namespace std;

class Player;

//Abstract enemy base class

class Enemy {
  protected:
    string enemyName;
    int hp;
    int maxHP;
    int attack;
    int defense;
    double hitChance; //probability of successfully hitting
    double critChance; //prob dealing crit damage
    string lootId;
    int turnCount;

    static std::mt19937& rng();
    bool hits(double chance) const;
    int baseDamageAgainst(const Player& player, int attackValue) const;
    void normalAttack(Player& player, const string& text = "");

  public:
    Enemy(const string& name, int hp, int attack, int defense, double hitChance, double critChance,
          const string& lootId = "");  //stats initialised in the constructor

    virtual ~Enemy() = default;

    string getName() const;
    int getHP() const;
    int getMaxHP() const;
    int getDefense() const;
    string getLootId() const;
    bool isAlive() const;

    void takeDamage(int damage);

    //making enemy abstract
    //every enemy type must define it's own application

    virtual void takeTurn(Player& player) = 0;
    virtual void specialAttack(Player& player) = 0;
    };

// Regular hotel enemies use this class.
// Every second turn they use Goblin Power: two quick reduced-damage hits.
class GoblinEnemy : public Enemy {
public:
    GoblinEnemy(const std::string& name, int hp, int attack, int defense,
                double hitChance, double critChance, const std::string& lootId = "");

    void takeTurn(Player& player) override;
    void specialAttack(Player& player) override;
};

// Skeleton behavior: every second turn is one heavy strike with lower hit chance.
class SkeletonEnemy : public Enemy {
public:
    SkeletonEnemy(const std::string& name, int hp, int attack, int defense,
                  double hitChance, double critChance, const std::string& lootId = "");

    void takeTurn(Player& player) override;
    void specialAttack(Player& player) override;
};

// Boss behavior for The Beast.
// It has two phases and uses Heavy Swing every third boss turn.
class BossEnemy : public Enemy {
private:
    bool enraged;

    void checkPhaseChange();

public:
    BossEnemy(const std::string& name, int hp, int attack, int defense,
              double hitChance, double critChance, const std::string& lootId = "");

    void takeTurn(Player& player) override;
    void specialAttack(Player& player) override;
};

#endif
