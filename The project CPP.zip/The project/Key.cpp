//
// Created by SUTI0007 on 2026-03-18.
//

#include "Key.h"
#include<iostream>

using namespace std;

Key::Key(const string& name) : Item(name) {}


void Key::use(Player&) {
   //Door unlocking is handled in Game::go()
}
