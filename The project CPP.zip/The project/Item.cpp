//
// Created by SUTI0007 on 2026-03-18.
//

#include "Item.h"

#include <utility>

Item::Item(std::string name)
    // std::move avoids copying the name string unnecessarily.
    : itemName(std::move(name)) {}

std::string Item::name() const {
  return itemName;
}