//
// Created by SUTI0007 on 2026-03-18.
//

#include "IIO.h"
#include<iostream>

using namespace std;

void IIO::showIntro() const {
  cout <<  "\nA cool wind moves across the desert road.\n"
                "A grand hotel stands alone before you, glowing in the night.\n\n"
                "They say this place is special.\n"
                "You may enter whenever you wish.\n\n"
                "But no one ever truely leaves.\n\n"
                "Don't trust the guests.\n"
                "Don't trust the voices.\n\n"
                "And if you want to escape,\n"
                "You must defeat the Beast!\n\n"
                "And everyone who stands in your way.\n\n"
                "WELCOME TO THE GAME."
            << endl;
}

void IIO::showHelp() const {
  cout<< "\nCommands:\n"
          "look                 show the room\n"
          "go <n|e|s|w>          move through an exit\n"
          "take <item>           pick up an item\n"
          "inv                  show inventory\n"
          "equip <weapon>        equip a weapon\n"
          "use <item>            use a consumable or key\n"
          "attack               attack the first enemy in the room\n"
          "help                 show commands\n"
          "quit                 leave the game\n"
   << endl;
}

void IIO::showSummary(bool won, int playerHP, int totalTurns) const{
  cout <<"\nSummary:\n";
  cout << "Result: " << (won ? "WIN" : "LOSS") << "\n";
  cout << "Player HP left: " << playerHP << "\n";
  cout << "Total turns: " << totalTurns << "\n";
}

std::string IIO::readLine(const std::string& prompt) const {
  // Prints a prompt, then reads the full command line.
  std::cout << prompt;
  std::string input;
  std::getline(std::cin, input);
  return input;
}

void IIO::waitBeforeExit() const {
  // Pause so the console window does not close immediately.
  std::cout << "\nThe Hotel California will be waiting if you ever return.\n";
  readLine("Press ENTER to close the game...");
}
