//
// Created by SUTI0007 on 2026-03-18.
//

#ifndef PLAYER_H
#define PLAYER_H
#include<iostream>
#include <vector>
#include <memory>
#include <string>

using namespace std;

class Weapon;
class Item;


//Code, Tech, and Tutorials-YT

//getter: a function that returns the value of private variable
//setter: a function that sets or modifies a private variable.

class Player{
   private:
    int currentHP, maxHP;
    int baseAttack, defense;
    int poisonTurns;

    Weapon* equippedWeapon;
    std::vector<std::unique_ptr<Item>> inventory; //owning pointers
  //creating a vector with uniqpointer pointing to an item in the inventory.

    Item* findItem(const string& itemName) const;


  public:
      Player(int hp = 30, int attack = 5, int defense = 2);


      int getCurrentHP() const;
      int getMaxHP() const;
      int getAttack() const;
      int getDefense() const;
      int getPoisonTurns() const;
      bool isAlive() const;


      void takeDamage(int damage);
      void heal(int amount);
      void poison(int turns);
      void applyPoisonDamage();

      //takes ownership of an item moved from room or loot drop
      bool addItem(std::unique_ptr<Item> item);
      void showInventory() const;
      bool hasItem(const string& itemName)const;

      //after use, should disappear
      bool removeItem(const string& itemName);
      bool equip(const string& weaponName);
      bool useItem(const string& itemName);

};
#endif //PLAYER_H