//
// Created by SUTI0007 on 2026-03-25.
//
#include "Game.h"
#include <iostream>

using namespace std;

int main() {
  Game game;

  if (!game.load("rooms.csv", "catalog.csv")){
    cout<< "Failed to load game data";
    return 1;
  }

 game.play();
 return 0;
 }


//In terminal, you can compile and run the game using the following //commands:
//cd "C:\OOP C++\The project"
//g++ main.cpp Game.cpp Player.cpp Room.cpp Enemy.cpp Weapon.cpp IIO.cpp Consumable.cpp Key.cpp Item.cpp -o game
//game.exe