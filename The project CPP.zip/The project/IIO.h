//
// Created by SUTI0007 on 2026-03-18.
//

#ifndef IIO_H
#define IIO_H
#include <iostream>
#include <string>

using namespace std;


class IIO {
    public:
      void showIntro() const;
      void showHelp() const;
      void showSummary(bool won, int playerHP, int totalTurns) const;
      string readLine(const string& prompt) const;
      void waitBeforeExit() const;
};

#endif //IIO_H
