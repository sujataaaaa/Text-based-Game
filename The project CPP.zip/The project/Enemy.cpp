//
// Created by SUTI0007 on 2026-03-18.
//

#include "Enemy.h"

#include "Player.h"

#include <algorithm>
#include <iostream>

//Goblin like: the nightclerk and the lost traveler
//Skeleton like:hungry skeleton, stronger than goblin but less accurate
//Boss like: The beast, phase change at 50 percent HP, stronger attacks and higher hit chance when enraged

Enemy::Enemy(const std::string& name, int hpValue, int attackValue,
             int defenseValue, double hitValue, double critValue,
             const std::string& lootValue)
    : enemyName(name),
      hp(hpValue),
      maxHP(hpValue),
      attack(attackValue),
      defense(defenseValue),
      hitChance(hitValue),
      critChance(critValue),
      lootId(lootValue),
      turnCount(0) {}

// One shared random engine for all enemy hit/crit rolls.
std::mt19937& Enemy::rng() {
    // Static means the engine is created once and reused.
    static std::mt19937 engine(std::random_device{}());
    return engine;
}

// Returns true if a random roll is within the given chance.
bool Enemy::hits(double chance) const {
    // Roll a number from 0.0 to 1.0.
    std::uniform_real_distribution<double> roll(0.0, 1.0);

    // Example: chance 0.8 means 80 percent hit chance.
    return roll(rng()) <= chance;
}

// Damage rule used by normal and special attacks.
int Enemy::baseDamageAgainst(const Player& player, int attackValue) const {
    return std::max(1, attackValue - player.getDefense());
}

// Shared normal attack behavior. Derived classes can call this instead of
// duplicating hit chance, crit chance, and damage code.
void Enemy::normalAttack(Player& player, const std::string& text) {
    // First roll to see if the attack connects.
    if (!hits(hitChance)) {
        std::cout << enemyName << " misses.\n";
        return;
    }

    // Calculate normal damage from attack minus player defense.
    int damage = baseDamageAgainst(player, attack);

    // Roll again for critical hit.
    if (hits(critChance)) {
        damage = static_cast<int>(damage * 1.5);
        std::cout << enemyName << " lands a critical hit!\n";
    }

    // Apply damage to the player.
    player.takeDamage(damage);

    // Optional extra text is used by the boss when enraged.
    if (!text.empty()) {
        std::cout << text << "\n";
    }
    std::cout << enemyName << " deals " << damage << " damage. You have "
              << player.getCurrentHP() << "/" << player.getMaxHP() << " HP.\n";
}

std::string Enemy::getName() const {
    return enemyName;
}

int Enemy::getHP() const {
    return hp;
}

int Enemy::getMaxHP() const {
    return maxHP;
}

int Enemy::getDefense() const {
    return defense;
}

std::string Enemy::getLootId() const {
    return lootId;
}

bool Enemy::isAlive() const {
    return hp > 0;
}

void Enemy::takeDamage(int damage) {
    // Enemy HP can go below zero internally; isAlive() checks hp > 0.
    hp -= std::max(0, damage);
}

GoblinEnemy::GoblinEnemy(const std::string& name, int hp, int attack, int defense,
                         double hitChance, double critChance, const std::string& lootId)
    : Enemy(name, hp, attack, defense, hitChance, critChance, lootId) {}

void GoblinEnemy::takeTurn(Player& player) {
    ++turnCount;

    // every 2nd enemy turn uses the special attack.
    if (turnCount % 2 == 0) {
        specialAttack(player);
    } else {
        normalAttack(player);
    }
}

void GoblinEnemy::specialAttack(Player& player) {
    std::cout << enemyName << " uses super power: two quick hits!\n";

    // Two smaller attacks. Each hit rolls separately.
    for (int i = 0; i < 2; ++i) {
        if (!hits(hitChance)) {
            std::cout << enemyName << "'s quick hit misses.\n";
            continue;
        }

        // Reduced damage: half of normal, but still at least 1.
        int damage = std::max(1, baseDamageAgainst(player, attack) / 2);
        player.takeDamage(damage);
        std::cout << enemyName << " quick hit deals " << damage << " damage.\n";
    }
}

SkeletonEnemy::SkeletonEnemy(const std::string& name, int hp, int attack, int defense,
                             double hitChance, double critChance, const std::string& lootId)
    : Enemy(name, hp, attack, defense, hitChance, critChance, lootId) {}

void SkeletonEnemy::takeTurn(Player& player) {
    ++turnCount;

    // Skeleton also follows the every-2nd-turn special pattern.
    if (turnCount % 2 == 0) {
        specialAttack(player);
    } else {
        normalAttack(player);
    }
}

void SkeletonEnemy::specialAttack(Player& player) {
    std::cout << enemyName << " raises both hands for a heavy bone strike!\n";

    // Heavy strike is stronger, but intentionally less accurate (requirement)
    if (!hits(0.55)) {
        std::cout << enemyName << "'s heavy strike misses.\n";
        return;
    }

    // Heavy strike uses bonus attack power.
    int damage = baseDamageAgainst(player, attack + 5);
    player.takeDamage(damage);
    std::cout << enemyName << " heavy strike deals " << damage << " damage. You have "
              << player.getCurrentHP() << "/" << player.getMaxHP() << " HP.\n";
}

BossEnemy::BossEnemy(const std::string& name, int hp, int attack, int defense,
                     double hitChance, double critChance, const std::string& lootId)
    : Enemy(name, hp, attack, defense, hitChance, critChance, lootId),
      enraged(false) {}

void BossEnemy::checkPhaseChange() {
    // Phase 2 starts once the boss reaches 50 percent HP or lower.
    // The message prints only once because enraged becomes true.
    if (!enraged && hp <= maxHP / 2) {
        enraged = true;

        // Phase 2 stat boost.
        attack += 3;
        hitChance = std::min(0.95, hitChance + 0.10);
        std::cout << "The Beast becomes enraged!\n";
    }
}

void BossEnemy::takeTurn(Player& player) {
    ++turnCount;
    checkPhaseChange();

    // Boss pattern: every 3rd boss turn uses Heavy Swing.
    if (turnCount % 3 == 0) {
        specialAttack(player);
    } else {
        normalAttack(player, enraged ? enemyName + " attacks with enraged force." : "");
    }
}

void BossEnemy::specialAttack(Player& player) {
    std::cout << enemyName << " uses Heavy Swing!\n";

    // Heavy Swing still uses the boss hit chance.
    if (!hits(hitChance)) {
        std::cout << enemyName << "'s Heavy Swing misses.\n";
        return;
    }

    // Heavy Swing is stronger than a normal attack.
    int damage = baseDamageAgainst(player, attack + 7);
    player.takeDamage(damage);
    std::cout << enemyName << " Heavy Swing deals " << damage << " damage. You have "
              << player.getCurrentHP() << "/" << player.getMaxHP() << " HP.\n";
}
