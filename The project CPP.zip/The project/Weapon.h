//
// Created by SUTI0007 on 2026-03-18.
//

#ifndef WEAPON_H
#define WEAPON_H
#include<iostream>

using namespace std;

#include"Item.h" //because weapon inherits from it

class Weapon : public Item { //Weapon class derives from Item, all public in Item are public in here
//Item has a pure virtual function use(), weapon must provide an implementation
private:
  int attackBonus;

public:
  Weapon(const std::string& name, int bonus);
  int bonus() const;

  //using a weapon equips it
  void use(Player& player) override;
};

#endif //WEAPON_H
