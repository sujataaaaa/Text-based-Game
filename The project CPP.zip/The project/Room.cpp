//
// Created by SUTI0007 on 2026-03-18.
//

#include "Room.h"

#include <algorithm>
#include <cctype>
#include <iostream>

namespace {
// Same idea as Player.cpp: normalize names for forgiving item pickup.
std::string itemKey(const std::string& text) {
    std::string key;

    // Remove punctuation/spaces and lowercase the rest.
    for (char ch : text) {
        if (std::isalnum(static_cast<unsigned char>(ch))) {
            key += static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        }
    }
    return key;
}
}

Room::Room(const std::string& idValue, const std::string& nameValue,
           const std::string& descValue)
    : roomId(idValue), roomName(nameValue), roomDescription(descValue) {}

const std::string& Room::id() const {
    return roomId;
}

const std::string& Room::name() const {
    return roomName;
}

const std::string& Room::description() const {
    return roomDescription;
}

const std::map<std::string, std::string>& Room::getExits() const {
    // Return all exits for display or inspection.
    return exits;
}

std::string Room::exitTo(const std::string& direction) const {
    // Look for the direction in the exit map.
    auto it = exits.find(direction);

    // Empty string means there is no exit that way.
    return it == exits.end() ? "" : it->second;
}

std::string Room::keyForExit(const std::string& direction) const {
    // Look for a key requirement on this direction.
    auto it = lockedExits.find(direction);
    return it == lockedExits.end() ? "" : it->second;
}

bool Room::isExitUnlocked(const std::string& direction) const {
    // Check whether this direction has already been opened with a key.
    return std::find(unlockedExits.begin(), unlockedExits.end(), direction) != unlockedExits.end();
}

void Room::addExit(const std::string& direction, const std::string& targetRoom) {
    // Blank target means the CSV did not define an exit there.
    if (!targetRoom.empty()) {
        exits[direction] = targetRoom;
    }
}

void Room::lockExit(const std::string& direction, const std::string& keyId) {
    // Store a lock only if both direction and key exist.
    if (!direction.empty() && !keyId.empty()) {
        lockedExits[direction] = keyId;
    }
}

void Room::unlockExit(const std::string& direction) {
    // The key is consumed only once. After this, the door stays unlocked.
    if (!isExitUnlocked(direction)) {
        unlockedExits.push_back(direction);
    }
}

void Room::addItem(std::unique_ptr<Item> item) {
    // Room takes ownership of the item.
    if (item) {
        items.push_back(std::move(item));
    }
}

void Room::addEnemy(std::unique_ptr<Enemy> enemy) {
    // Room takes ownership of the polymorphic enemy.
    if (enemy) {
        enemies.push_back(std::move(enemy));
    }
}

void Room::describe() const {
    // Main room display for the look command and after moving.
    std::cout << "\n" << roomName << "\n";
    std::cout << roomDescription << "\n";

    std::cout << "Exits:";
    if (exits.empty()) {
        std::cout << " none";
    } else {
        for (const auto& exit : exits) {
            std::cout << " " << exit.first;

            // A locked exit is marked only while it has not yet been opened.
            if (keyForExit(exit.first) != "" && !isExitUnlocked(exit.first)) {
                std::cout << "(locked)";
            }
        }
    }
    std::cout << "\n";

    std::cout << "Items:";
    if (items.empty()) {
        std::cout << " none";
    } else {
        for (const auto& item : items) {
            std::cout << "\n- " << item->name();
        }
    }
    std::cout << "\n";

    std::cout << "Enemies:";
    if (enemies.empty()) {
        std::cout << " none";
    } else {
        for (const auto& enemy : enemies) {
            std::cout << " " << enemy->getName() << "(HP " << enemy->getHP() << ")";
        }
    }
    std::cout << "\n";
}

void Room::showEnemyStatus() const {
    // Extra helper for summaries/debugging.
    if (enemies.empty()) {
        std::cout << "Enemies left: none\n";
        return;
    }

    std::cout << "Enemies left:\n";
    for (const auto& enemy : enemies) {
        std::cout << "- " << enemy->getName() << " | HP " << enemy->getHP() << "\n";
    }
}

std::unique_ptr<Item> Room::takeItem(const std::string& itemName) {
    // Normalize player input before comparing names.
    std::string wanted = itemKey(itemName);
    if (wanted.empty()) {
        return nullptr;
    }

    auto it = std::find_if(items.begin(), items.end(),
        [&wanted](const std::unique_ptr<Item>& item) {
            return itemKey(item->name()) == wanted;
    });

    // Partial matching makes commands like "take dagger" work.
    if (it == items.end()) {
        it = std::find_if(items.begin(), items.end(),
            [&wanted](const std::unique_ptr<Item>& item) {
                return itemKey(item->name()).find(wanted) != std::string::npos;
            });
    }

    if (it == items.end()) {
        // Returning nullptr tells Game that taking failed.
        return nullptr;
    }

    // Move ownership out of the room and return it to Game/Player.
    std::unique_ptr<Item> item = std::move(*it);
    items.erase(it);
    return item;
}

Enemy* Room::firstEnemy() {
    if (enemies.empty()) {
        return nullptr;
    }
    // Return a non-owning raw pointer. Room still owns the enemy unique_ptr.
    return enemies.front().get();
}

void Room::removeDeadEnemies() {
    // Erasing a unique_ptr automatically destroys the defeated enemy.
    enemies.erase(std::remove_if(enemies.begin(), enemies.end(),
        [](const std::unique_ptr<Enemy>& enemy) {
            return !enemy->isAlive();
        }), enemies.end());
}

bool Room::hasEnemyNamed(const std::string& enemyName) const {
    // Used by Game::checkWin() to see whether The Beast is gone.
    return std::any_of(enemies.begin(), enemies.end(),
        [&enemyName](const std::unique_ptr<Enemy>& enemy) {
            return enemy->getName() == enemyName;
        });
}

