#ifndef GAME_H
#define GAME_H

#include "Enemy.h"
#include "IIO.h"
#include "Item.h"
#include "Player.h"
#include "Room.h"

#include <functional>
#include <map>
#include <memory>
#include <random>
#include <string>

// Main controller class.
// Game loads files, creates rooms/items/enemies, reads commands,
// moves the player, runs combat, and checks win/loss conditions.
class Game {
private:
    Player player;
    std::map<std::string, Room> rooms;

    // Catalogs are factory maps:
    // ID -> function that creates a new object when a room needs it.
    std::map<std::string, std::function<std::unique_ptr<Item>()>> itemCatalog;
    std::map<std::string, std::function<std::unique_ptr<Enemy>()>> enemyCatalog;

    // Player location is tracked by room ID.
    std::string currentRoomId;

    std::mt19937 rng;
    IIO io;
    bool running;
    bool won;
    int totalTurns;

    static std::string trim(const std::string& text);

    // Converts user text or CSV IDs into a consistent lookup key.
    // Example: "silver dagger" -> "SILVER_DAGGER".
    static std::string commandKey(const std::string& text);

    // Converts an ID into text shown to the player.
    // Example: "SILVER_DAGGER" -> "Silver Dagger".
    static std::string prettyName(const std::string& id);

    Room* currentRoom();
    void loadCatalog(const std::string& filename);
    void resolveRoomContents();
    void handleCommand(const std::string& input);
    void go(const std::string& direction);
    void take(const std::string& itemName);
    void attack();

    // Runs end-of-combat-turn effects and prints the HP histogram.
    void finishTurn();
    void printHpHistogram() const;

    // Called when an enemy dies. Uses a 50 percent chance to drop loot.
    void tryDropLoot(const std::string& enemyName, const std::string& lootId);
    void checkWin();

public:
    Game();

    bool load(const std::string& roomsFile, const std::string& catalogFile);
    void play();
};

#endif

