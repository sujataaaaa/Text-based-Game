//
// Created by SUTI0007 on 2026-03-18.
//

#ifndef ROOM_H
#define ROOM_H

#include "Enemy.h"
#include "Item.h"

#include <map>
#include <memory>
#include <string>
#include <vector>

// Represents one location in the hotel.
// A room owns the items and enemies currently inside it.
class Room {
private:
    std::string roomId;
    std::string roomName;
    std::string roomDescription;

    // Direction -> destination room ID, for example "e" -> "R2".
    std::map<std::string, std::string> exits;

    // Direction -> required key ID, for example "s" -> "ORNATE_KEY".
    std::map<std::string, std::string> lockedExits;

    // Once a key has opened a door, the direction is remembered here.
    std::vector<std::string> unlockedExits;

    // Rooms own their polymorphic items and enemies with unique_ptr.
    std::vector<std::unique_ptr<Item>> items;
    std::vector<std::unique_ptr<Enemy>> enemies;

public:
    // Temporary IDs loaded from rooms.csv. Game::resolveRoomContents()
    // uses these IDs to create real Item and Enemy objects from catalog.csv.
    std::vector<std::string> itemIDs;
    std::vector<std::string> enemyIDs;

    Room() = default;
    Room(const std::string& id, const std::string& name, const std::string& desc);

    const std::string& id() const;
    const std::string& name() const;
    const std::string& description() const;
    const std::map<std::string, std::string>& getExits() const;
    std::string exitTo(const std::string& direction) const;
    std::string keyForExit(const std::string& direction) const;
    bool isExitUnlocked(const std::string& direction) const;

    void addExit(const std::string& direction, const std::string& targetRoom);
    void lockExit(const std::string& direction, const std::string& keyId);
    void unlockExit(const std::string& direction);
    void addItem(std::unique_ptr<Item> item);
    void addEnemy(std::unique_ptr<Enemy> enemy);

    void describe() const;
    void showEnemyStatus() const;

    // Removes an item from the room and returns ownership to the caller.
    std::unique_ptr<Item> takeItem(const std::string& itemName);

    // Non-owning pointer to the first enemy. Room still owns the enemy.
    Enemy* firstEnemy();
    void removeDeadEnemies();
    bool hasEnemyNamed(const std::string& enemyName) const;
};

#endif

