//
// Created by SUTI0007 on 2026-03-18.
//

#ifndef ITEM_H
#define ITEM_H
#include <string>
#include<iostream>

using namespace std;

class Player;

class Item {
  private:  //means accesible by item and derived classes but not by outside code
    string itemName;  //stores a name of an item like sword,etc

  public:
    //prevents
  explicit Item(std::string name);
  virtual ~Item() = default;  //virtual destructor

  string name() const;

  //each derived class determines what use is
  virtual void use(Player& player) = 0; //0 means no implementation here
};

#endif //ITEM_H

//an abstract base class for different items in this game.
//Holds the name for the item and gives a common interface use() that all items must implement
//use of virtual destructor-safe for inheritance
