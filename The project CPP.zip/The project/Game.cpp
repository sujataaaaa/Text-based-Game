#include "Game.h"

#include "Consumable.h"
#include "Key.h"
#include "Weapon.h"

#include <algorithm>
#include <cctype>
#include <fstream>
#include <iostream>
#include <sstream>
#include <utility>

Game::Game()
    : player(30, 5, 2),          // Create the player with HP 30, attack 5, defense 2.
      rng(std::random_device{}()), // Seed the game's random engine.
      running(true),             // The command loop should start active.
      won(false),                // The player has not won at the start.
      totalTurns(0) {}           // Combat turn counter starts at 0.

// Removes spaces from the start and end of strings read from CSV/user input.
std::string Game::trim(const std::string& text) {
    // Find the first non-space character.
    size_t start = 0;
    while (start < text.size() && std::isspace(static_cast<unsigned char>(text[start]))) {
        ++start;
    }

    // Find one past the last non-space character.
    size_t end = text.size();
    while (end > start && std::isspace(static_cast<unsigned char>(text[end - 1]))) {
        --end;
    }

    // Return only the useful middle part.
    return text.substr(start, end - start);
}

std::string Game::commandKey(const std::string& text) {
    // Start with trimmed input so extra spaces do not matter.
    std::string key = trim(text);

    // Treat spaces and hyphens like underscores because the CSV uses IDs.
    std::replace(key.begin(), key.end(), '-', '_');
    std::replace(key.begin(), key.end(), ' ', '_');

    // Convert to uppercase so user commands are case-insensitive.
    for (char& ch : key) {
        ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    }
    return key;
}

std::string Game::prettyName(const std::string& id) {
    // Copy the ID so the original string is not changed.
    std::string name = id;

    // Display names use spaces instead of underscores.
    std::replace(name.begin(), name.end(), '_', ' ');

    // Capitalize the first letter of each word.
    bool newWord = true;
    for (char& ch : name) {
        if (std::isspace(static_cast<unsigned char>(ch))) {
            // The next non-space character begins a new word.
            newWord = true;
        } else if (newWord) {
            ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
            newWord = false;
        } else {
            // Lowercase the rest of each word for clean display.
            ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        }
    }
    return name;
}

Room* Game::currentRoom() {
    // The game stores the current location by room ID, then looks up the Room.
    auto it = rooms.find(currentRoomId);
    return it == rooms.end() ? nullptr : &it->second;
}

bool Game::load(const std::string& roomsFile, const std::string& catalogFile) {
    // Catalog must be loaded first because room entries only contain item/enemy IDs.
    loadCatalog(catalogFile);

    // Open the room file after catalog loading.
    std::ifstream file(roomsFile);
    if (!file) {
        std::cout << "Could not open " << roomsFile << ".\n";
        return false;
    }

    // Read the room file line by line.
    std::string line;
    bool firstLine = true;
    while (std::getline(file, line)) {
        // Skip blank lines.
        if (trim(line).empty()) {
            continue;
        }

        // Skip the CSV header line.
        if (firstLine && line.find("id;") == 0) {
            firstLine = false;
            continue;
        }
        firstLine = false;

        // Use stringstream so getline can split this one line by semicolons.
        std::stringstream ss(line);
        std::string id, name, desc, n, e, s, w, items, enemies, locks;

        // Read each CSV column into a variable.
        std::getline(ss, id, ';');
        std::getline(ss, name, ';');
        std::getline(ss, desc, ';');
        std::getline(ss, n, ';');
        std::getline(ss, e, ';');
        std::getline(ss, s, ';');
        std::getline(ss, w, ';');
        std::getline(ss, items, ';');
        std::getline(ss, enemies, ';');
        std::getline(ss, locks, ';');

        id = trim(id);

        // Create the room object, then add exits and raw ID lists from CSV.
        Room room(id, trim(name), trim(desc));

        // Empty exits are ignored inside Room::addExit().
        room.addExit("n", trim(n));
        room.addExit("e", trim(e));
        room.addExit("s", trim(s));
        room.addExit("w", trim(w));

        // Items in the CSV are separated with |, for example A|B|C.
        std::stringstream itemStream(items);
        std::string token;
        while (std::getline(itemStream, token, '|')) {
            token = commandKey(token);
            if (!token.empty()) {
                // Store IDs first. Real objects are created after all rooms load.
                room.itemIDs.push_back(token);
            }
        }

        // Enemies are also stored as | separated IDs.
        std::stringstream enemyStream(enemies);
        while (std::getline(enemyStream, token, '|')) {
            token = commandKey(token);
            if (!token.empty()) {
                room.enemyIDs.push_back(token);
            }
        }

        // Locks are written as direction=KEY_ID, for example s=ORNATE_KEY.
        std::stringstream lockStream(locks);
        while (std::getline(lockStream, token, '|')) {
            size_t equals = token.find('=');
            if (equals == std::string::npos) {
                // If the lock is malformed, ignore it instead of crashing.
                continue;
            }

            // Left side is the direction, right side is the required key.
            std::string direction = commandKey(token.substr(0, equals));
            std::string keyId = commandKey(token.substr(equals + 1));

            // Directions are stored lowercase: n, e, s, w.
            for (char& ch : direction) {
                ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
            }
            room.lockExit(direction, keyId);
        }

        // First room in the CSV becomes the starting room.
        if (currentRoomId.empty()) {
            currentRoomId = id;
        }
        // Room contains unique_ptr vectors, so move it into the map.
        rooms.emplace(id, std::move(room));
    }

    // Now that all rooms exist, replace IDs with real items and enemies.
    resolveRoomContents();

    // Loading succeeded if at least one room exists.
    return !rooms.empty();
}

void Game::loadCatalog(const std::string& filename) {
    // Open the catalog file. It contains both items and enemy definitions.
    std::ifstream file(filename);
    if (!file) {
        std::cout << "Could not open " << filename << ".\n";
        return;
    }

    std::string line;
    while (std::getline(file, line)) {
        // Ignore empty lines and the header row.
        if (trim(line).empty() || line.find("type;") == 0) {
            continue;
        }

        // Split the catalog line by semicolons.
        std::stringstream ss(line);
        std::string type, id, field1, field2;
        std::getline(ss, type, ';');
        std::getline(ss, id, ';');
        std::getline(ss, field1, ';');
        std::getline(ss, field2, ';');

        type = commandKey(type); // ITEM or ENEMY.
        id = commandKey(id);     // Catalog lookup ID.
        field1 = trim(field1);   // Item subtype or enemy stats.
        field2 = trim(field2);   // Item value or enemy extras.

        if (type == "ITEM") {
            // For items, field1 tells us the kind and field2 is the number value.
            std::string itemType = commandKey(field1);
            int value = field2.empty() ? 0 : std::stoi(field2);

            // Each catalog entry stores a factory function.
            // Calling itemCatalog[id]() later creates a fresh item object.
            if (itemType == "WEAPON") {
                itemCatalog[id] = [id, value]() {
                    // A weapon uses value as attack bonus.
                    return std::make_unique<Weapon>(prettyName(id), value);
                };
            } else if (itemType == "CONSUMABLE") {
                itemCatalog[id] = [id, value]() {
                    // A consumable uses value as healing amount.
                    return std::make_unique<Consumable>(prettyName(id), value);
                };
            } else if (itemType == "KEY") {
                itemCatalog[id] = [id]() {
                    // Key value is not needed for this project.
                    return std::make_unique<Key>(prettyName(id));
                };
            }
        } else if (type == "ENEMY") {
            // For enemies, field1 contains multiple stats in comma-separated key=value pairs.
            //Mentioned in the canvas (hit and crit chance)
            int hp = 1;
            int atk = 1;
            int def = 0;
            double hit = 0.8;
            double crit = 0.2;

            // Enemy stats use comma-separated key=value pairs.
            std::stringstream stats(field1);
            std::string stat;
            while (std::getline(stats, stat, ',')) {
                size_t equals = stat.find('=');
                if (equals == std::string::npos) {
                    continue;
                }

                // Split each stat into name and value.
                std::string key = commandKey(stat.substr(0, equals));
                std::string value = trim(stat.substr(equals + 1));

                // Put each recognized stat into the matching variable.
                if (key == "HP") {
                    hp = std::stoi(value);
                } else if (key == "ATK") {
                    atk = std::stoi(value);
                } else if (key == "DEF") {
                    def = std::stoi(value);
                } else if (key == "HIT") {
                    hit = std::stod(value);
                } else if (key == "CRIT") {
                    crit = std::stod(value);
                }
            }

            std::string lootId;

            // Extra enemy data currently stores only loot, for example:
            // ENEMY;THE_BEAST;hp=26,...;loot=ANCIENT_HAMMER
            std::stringstream extra(field2);
            std::string extraToken;
            while (std::getline(extra, extraToken, ',')) {
                size_t equals = extraToken.find('=');
                if (equals == std::string::npos) {
                    continue;
                }

                // Parse optional enemy extras.
                std::string key = commandKey(extraToken.substr(0, equals));
                std::string value = commandKey(extraToken.substr(equals + 1));
                if (key == "LOOT") {
                    lootId = value;
                }
            }

            // Enemy factory chooses the correct derived enemy class.
            // The Beast is the boss, names containing SKELETON become skeletons,
            // and all other enemies use Goblin behavior.
            enemyCatalog[id] = [id, hp, atk, def, hit, crit, lootId]() -> std::unique_ptr<Enemy> {
                if (id == "THE_BEAST") {
                    return std::make_unique<BossEnemy>(prettyName(id), hp, atk, def, hit, crit, lootId);
                }
                if (id.find("SKELETON") != std::string::npos) {
                    return std::make_unique<SkeletonEnemy>(prettyName(id), hp, atk, def, hit, crit, lootId);
                }
                return std::make_unique<GoblinEnemy>(prettyName(id), hp, atk, def, hit, crit, lootId);
            };
        }
    }
}

void Game::resolveRoomContents() {
    // Convert the IDs loaded into each room into real Item and Enemy objects.
    for (auto& pair : rooms) {
        // pair.first is the room ID, pair.second is the Room object.
        Room& room = pair.second;

        // Add all item objects listed by ID in rooms.csv.
        for (const std::string& itemId : room.itemIDs) {
            auto itemIt = itemCatalog.find(itemId);
            if (itemIt != itemCatalog.end()) {
                // Factory returns unique_ptr<Item>; room takes ownership.
                room.addItem(itemIt->second());
            }
        }

        // Add all enemy objects listed by ID in rooms.csv.
        for (const std::string& enemyId : room.enemyIDs) {
            auto enemyIt = enemyCatalog.find(enemyId);
            if (enemyIt != enemyCatalog.end()) {
                // Factory returns unique_ptr<Enemy>; room takes ownership.
                room.addEnemy(enemyIt->second());
            }
        }
    }
}

void Game::play() {
    // Show story and controls once at the beginning.
    io.showIntro();
    io.showHelp();

    // Show the starting room immediately.
    if (Room* room = currentRoom()) {
        room->describe();
    }

    while (running && player.isAlive() && !won) {
        // Main command loop. It stops when user quits, player dies, or player wins.
        handleCommand(io.readLine("\n> "));
        checkWin();
    }

    // Print the correct ending message after the loop stops.
    if (!player.isAlive()) {
        std::cout << "\nThe music fades. The hotel keeps another guest.\nGame Over.\n";
    } else if (won) {
        std::cout << "\nThe Beast falls. Dawn reaches the lobby at last.\nYou leave the Hotel California alive.\n";
    }

    io.showSummary(won, player.getCurrentHP(), totalTurns);
    io.waitBeforeExit();
}

void Game::handleCommand(const std::string& input) {
    // Split command into the first word and the rest of the line.
    // Example: "take rusty knife" -> command "take", rest "rusty knife".
    std::stringstream ss(trim(input));
    std::string command;

    // Read the first word as the command name.
    ss >> command;

    // Normalize command so "Look", "LOOK", and "look" are the same.
    command = commandKey(command);

    std::string rest;

    // Everything after the first word is the command argument.
    std::getline(ss, rest);
    rest = trim(rest);

    // Empty input just does nothing.
    if (command.empty()) {
        return;
    }

    // Each branch calls a small helper function when possible.
    if (command == "LOOK") {
        if (Room* room = currentRoom()) {
            room->describe();
        }
    } else if (command == "GO") {
        go(commandKey(rest));
    } else if (command == "TAKE") {
        take(rest);
    } else if (command == "INV" || command == "INVENTORY") {
        player.showInventory();
    } else if (command == "EQUIP") {
        player.equip(prettyName(commandKey(rest)));
    } else if (command == "USE") {
        player.useItem(prettyName(commandKey(rest)));
    } else if (command == "ATTACK") {
        attack();
    } else if (command == "HELP") {
        io.showHelp();
    } else if (command == "QUIT") {
        std::cout << "You can check out any time you like... but today, the game closes politely.\n";
        running = false;
    } else {
        std::cout << "The hotel does not understand that command.\n";
    }
}

void Game::go(const std::string& direction) {
    // Get the current room. If this fails, movement cannot happen.
    Room* room = currentRoom();
    if (!room) {
        return;
    }

    // Direction is stored lowercase in the Room.
    std::string exitDirection = direction;
    for (char& ch : exitDirection) {
        ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    }

    // Ask the room where this exit leads.
    std::string target = room->exitTo(exitDirection);
    if (target.empty()) {
        std::cout << "There is no door that way. The hallway hums like it knows.\n";
        return;
    }

    // Check whether this direction has a lock.
    std::string neededKey = room->keyForExit(exitDirection);
    if (!neededKey.empty() && !room->isExitUnlocked(exitDirection)) {
        // Locked exits require the matching key in inventory.
        if (!player.hasItem(prettyName(neededKey))) {
            std::cout << "The door is locked.\n";
            return;
        }

        // The key is consumed, but the room remembers that this exit is unlocked.
        player.removeItem(prettyName(neededKey));
        room->unlockExit(exitDirection);
        std::cout << "You use " << prettyName(neededKey) << " to unlock the door. It stays open.\n";
    }

    // Update player location.
    currentRoomId = target;

    // Show the new room after moving.
    if (Room* nextRoom = currentRoom()) {
        nextRoom->describe();
    }
}

void Game::take(const std::string& itemName) {
    // Items are taken from the room the player currently occupies.
    Room* room = currentRoom();
    if (!room) {
        return;
    }

    // takeItem moves ownership from the Room into this local unique_ptr.
    std::unique_ptr<Item> item = room->takeItem(prettyName(commandKey(itemName)));
    if (!item) {
        // nullptr means no matching item was found in the room.
        std::cout << "You do not see that item here.\n";
        return;
    }

    // addItem moves ownership from this function into Player inventory.
    player.addItem(std::move(item));
}

void Game::attack() {
    // Combat happens only against enemies in the current room.
    Room* room = currentRoom();
    if (!room) {
        return;
    }

    Enemy* enemy = room->firstEnemy();
    if (!enemy) {
        // No enemies means attack is a harmless command.
        std::cout << "There is nothing here to attack.\n";
        return;
    }

    // Save data needed after the enemy might be removed from the room.
    std::string enemyName = enemy->getName();
    std::string lootId = enemy->getLootId();
    std::cout << "\n-- Player turn --\n";

    std::uniform_real_distribution<double> roll(0.0, 1.0);

    // Player attack uses the Grade 3 combat rules.
    if (roll(rng) > 0.8) {
        // Player missed the attack.
        std::cout << "You swing at " << enemy->getName() << " and miss.\n";
    } else {
        // Calculate player damage with the required formula.
        int damage = std::max(1, player.getAttack() - enemy->getDefense());
        if (roll(rng) <= 0.2) {
            // Critical hit multiplies damage by 1.5 and truncates to int.
            damage = static_cast<int>(damage * 1.5);
            std::cout << "Critical hit!\n";
        }

        // Apply damage to the enemy.
        enemy->takeDamage(damage);
        std::cout << "You hit " << enemy->getName() << " for " << damage << " damage.\n";
    }

    // If the player killed the enemy, remove it before enemy turn happens.
    if (!enemy->isAlive()) {
        std::cout << enemyName << " is defeated.\n";
        room->removeDeadEnemies();
        tryDropLoot(enemyName, lootId);
        finishTurn();
        return;
    }

    // Enemy turn uses virtual dispatch:
    // GoblinEnemy, SkeletonEnemy, or BossEnemy decides what happens.
    std::cout << "\n-- Enemy turn: " << enemy->getName() << " --\n";
    enemy->takeTurn(player);
    finishTurn();
}

void Game::finishTurn() {
    // Poison happens at the end of combat turns, then the histogram prints.
    player.applyPoisonDamage();

    // A "turn" means one full player/enemy combat exchange.
    ++totalTurns;

    // Show required HP bar after status effects.
    printHpHistogram();
}

void Game::printHpHistogram() const {
    // Clamp HP to zero so the bar never tries to print a negative amount.
    int safePlayerHP = std::max(0, player.getCurrentHP());

    std::cout << "Updated status:\n";
    std::cout << "Player: Turn " << totalTurns << " | HP " << safePlayerHP << " | ";
    for (int i = 0; i < safePlayerHP; ++i) {
        std::cout << "#";
    }
    std::cout << "\n";
}

void Game::tryDropLoot(const std::string& enemyName, const std::string& lootId) {
    if (lootId.empty()) {
        // Some enemies may not have loot configured.
        return;
    }

    std::uniform_real_distribution<double> roll(0.0, 1.0);

    // Fixed 50 percent drop chance.
    if (roll(rng) > 0.5) {
        std::cout << enemyName << " drops nothing.\n";
        return;
    }

    auto itemIt = itemCatalog.find(lootId);
    if (itemIt == itemCatalog.end()) {
        // If loot ID is not in the catalog, do not crash.
        return;
    }

    std::cout << enemyName << " drops " << prettyName(lootId) << ".\n";
    Room* room = currentRoom();
    if (room) {
        // Dropped loot is added to the room so the player can use take <item>.
        room->addItem(itemIt->second());
    }
}

void Game::checkWin() {
    Room* room = currentRoom();
    if (!room) {
        return;
    }

    // Current win condition: The Beast is gone from the Master Chamber.
    if (room->name() == "Master Chamber" && !room->hasEnemyNamed("The Beast")) {
        won = true;
    }
}
