The theme of the game is inspired by the song Hotel California by Eagles.

The player explores the romms in a hotel setting, picks up the items, unlocks the Master Chamber and defeats the beast to with the game.

#Build and Run#
1) Open your terminal
2) Type -> cd  "directory of the project folder"
3) Type -> g++ main.cpp Game.cpp Player.cpp Room.cpp Enemy.cpp Weapon.cpp IIO.cpp Consumable.cpp Key.cpp Item.cpp -o game
4) Type -> game.exe

Room desigen:
"Hotel Entrance" leads to "Lobby" to the east. 
"Lobby" has "Hotel Entrance" to the west, "The master chamber" (locked) to the south and "The feast hall" to the east.
"The feast hall" has "lobby" to the west.
"The Master chamber" has "lobby" to the north.

#Commands#
look - shows you the current room, exists, items and enemies
go <n|e|s|w> - go the direction you want/can (write only an alphabet n/e/s/w)
take <item> - pick up an item
inv - show the inventory
equip <item> - equip a weapon
use <item> - use a consumable
attack - attack the enemy if present
help - shows commands
quit - exit the game

There is some error handling so the take<item> command accepts variety of input for eg. only "take silver" or only take "dagger",etc


#Game Design#
The project uses OOP classes for Game, Room, Player, Item, Weapon,
Consumable, Key, and a polymorphic enemy hierarchy.

Enemy is an abstract base class with virtual `takeTurn(Player&)` and
`specialAttack(Player&)` functions. The derived classes are:

-GoblinEnemy - used for regular enemies like the lost traveler and the night clerk. Every second enemy turn uses
  Goblin Power: two quick reduced-damage hits.
-SkeletonEnemy - used for the Hungry Skeleton. Every second enemy turn uses
  one heavy strike with lower hit chance.
-BossEnemy - used for The Beast.

Rooms and items are loaded from CSV files. `rooms.csv` defines room exits,
items, enemies, and locked exits. `catalog.csv` defines item stats and enemy
stats/loot.

Owned polymorphic objects use `std::unique_ptr`:

- Room items: `std::vector<std::unique_ptr<Item>>`
- Player inventory: `std::vector<std::unique_ptr<Item>>`
- Room enemies: `std::vector<std::unique_ptr<Enemy>>`

The Player gets poisoned in the first three truns.
The enemies leaves an item after being defeated.
The Master Chamber needs to the ornate key to get unlocked.
The players can be seen after each attack (histogram) but to look at enemies command "look" and there one one see.
The beast has 2 phases: 1) normal attacks, heavy swing in every 3 swings
2) The beast gets enraged with more attack power and hitchances.

At last, the game shows the Summary with results, player hp and turns.

