//
// Created by SUTI0007 on 2026-03-18.
//

#ifndef KEY_H
#define KEY_H
#include<iostream>
#include "Item.h"

using namespace std;

//Key is in the inventory
//Game::go() checks if the key is in the inv

class Key : public Item {

public:
  explicit Key(const string& name);

  void use(Player& player) override;
};

#endif //KEY_H
