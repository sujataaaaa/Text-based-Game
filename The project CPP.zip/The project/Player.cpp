#include "Player.h"

#include "Consumable.h"
#include "Item.h"
#include "Weapon.h"

#include <algorithm>
#include <cctype>
#include <iostream>


namespace {
// Normalizes item names so commands are forgiving.
// "silver dagger", "SILVER_DAGGER", and "dagger" become easier to match.
std::string itemKey(const std::string& text) {
    std::string key;

    // Keep only letters/numbers and lowercase them.
    for (char ch : text) {
        if (std::isalnum(static_cast<unsigned char>(ch))) {
            key += static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
        }
    }
    return key;
}
}

Player::Player(int hp, int attack, int defenseValue)
    : currentHP(hp),
      maxHP(hp),
      baseAttack(attack),
      defense(defenseValue),
      // The player starts poisoned for the first three combat turns.
      poisonTurns(3),
      equippedWeapon(nullptr) {}

Item* Player::findItem(const std::string& itemName) const {
    // Convert the search text into the same simple key format.
    std::string wanted = itemKey(itemName);
    if (wanted.empty()) {
        return nullptr;
    }

    // First try exact matching.
    for (const auto& item : inventory) {
        if (itemKey(item->name()) == wanted) {
            return item.get();
        }
    }

    // If exact match fails, allow partial matching like "knife" for "Rusty Knife".
    for (const auto& item : inventory) {
        if (itemKey(item->name()).find(wanted) != std::string::npos) {
            return item.get();
        }
    }

    return nullptr;
}

int Player::getCurrentHP() const {
    return currentHP;
}

int Player::getMaxHP() const {
    return maxHP;
}

int Player::getAttack() const {
    // Equipped weapon adds to base attack, but the player does not own the
    // weapon through this pointer. The inventory unique_ptr still owns it.
    return baseAttack + (equippedWeapon ? equippedWeapon->bonus() : 0);
}

int Player::getDefense() const {
    return defense;
}

int Player::getPoisonTurns() const {
    return poisonTurns;
}

bool Player::isAlive() const {
    return currentHP > 0;
}

void Player::takeDamage(int damage) {
    // Damage cannot heal the player, so negative values are ignored.
    currentHP -= std::max(0, damage);

    // HP should not go below zero.
    if (currentHP < 0) {
        currentHP = 0;
    }
}

void Player::heal(int amount) {
    // Heal up to max HP, never above it.
    currentHP = std::min(maxHP, currentHP + std::max(0, amount));
    std::cout << "You now have " << currentHP << "/" << maxHP << " HP.\n";
}

void Player::poison(int turns) {
    // Keep the longer poison duration if the player is poisoned again.
    if (turns > poisonTurns) {
        poisonTurns = turns;
        std::cout << "Poison burns through your veins.\n";
    }
}

void Player::applyPoisonDamage() {
    // No poison effect if duration is gone or the player already died.
    if (poisonTurns <= 0 || !isAlive()) {
        return;
    }

    // Poison damage is fixed at 5 HP.
    takeDamage(5);

    // One poison turn has now been used.
    --poisonTurns;
    std::cout << "You are Poisoned! Damage: 5 HP. You have " << currentHP
              << "/" << maxHP << " HP.\n";
}

bool Player::addItem(std::unique_ptr<Item> item) {
    // Do not add an empty pointer.
    if (!item) {
        return false;
    }

    // Inventory limit required by the project.
    if (inventory.size() >= 8) {
        std::cout << "Inventory full. You can carry only 8 items.\n";
        return false;
    }

    // Ownership moves into the inventory here.
    std::cout << "Taken: " << item->name() << "\n";
    inventory.push_back(std::move(item));
    return true;
}

void Player::showInventory() const {
    // Empty inventory gets a special message.
    if (inventory.empty()) {
        std::cout << "Your inventory is empty.\n";
        return;
    }

    std::cout << "Inventory:\n";
    for (const auto& item : inventory) {
        // Print every item name.
        std::cout << "- " << item->name();

        // Mark the equipped weapon so the player can see it.
        if (item.get() == equippedWeapon) {
            std::cout << " (equipped)";
        }
        std::cout << "\n";
    }
}

bool Player::hasItem(const std::string& itemName) const {
    return findItem(itemName) != nullptr;
}

bool Player::removeItem(const std::string& itemName) {
    // Used mostly for consuming keys when opening locked doors.
    std::string wanted = itemKey(itemName);
    if (wanted.empty()) {
        return false;
    }

    auto it = std::find_if(inventory.begin(), inventory.end(),
        [&wanted](const std::unique_ptr<Item>& item) {
            return itemKey(item->name()) == wanted;
        });

    // If exact matching fails, try partial matching.
    if (it == inventory.end()) {
        it = std::find_if(inventory.begin(), inventory.end(),
            [&wanted](const std::unique_ptr<Item>& item) {
                return itemKey(item->name()).find(wanted) != std::string::npos;
            });
    }

    if (it == inventory.end()) {
        return false;
    }

    // If the removed item was equipped, clear the non-owning pointer first.
    if (it->get() == equippedWeapon) {
        equippedWeapon = nullptr;
    }
    inventory.erase(it);
    return true;
}

bool Player::equip(const std::string& weaponName) {
    Item* item = findItem(weaponName);

    // dynamic_cast checks whether the found Item is actually a Weapon.
    auto* weapon = dynamic_cast<Weapon*>(item);
    if (!weapon) {
        std::cout << "You do not have that weapon.\n";
        return false;
    }

    equippedWeapon = weapon;
    std::cout << "Equipped " << weapon->name()
              << ". Attack is now " << getAttack() << ".\n";
    return true;
}

bool Player::useItem(const std::string& itemName) {
    // Normalize the requested item name.
    std::string wanted = itemKey(itemName);
    if (wanted.empty()) {
        std::cout << "Use what?\n";
        return false;
    }

    auto it = std::find_if(inventory.begin(), inventory.end(),
        [&wanted](const std::unique_ptr<Item>& item) {
            return itemKey(item->name()) == wanted;
        });

    // Allow partial item names for use commands too.
    if (it == inventory.end()) {
        it = std::find_if(inventory.begin(), inventory.end(),
            [&wanted](const std::unique_ptr<Item>& item) {
                return itemKey(item->name()).find(wanted) != std::string::npos;
            });
    }

    if (it == inventory.end()) {
        std::cout << "You do not have that item.\n";
        return false;
    }

    // Consumables disappear after use; weapons/keys stay unless another part
    // of the game removes them, such as a key opening a locked door.
    bool removeAfterUse = dynamic_cast<Consumable*>(it->get()) != nullptr;
    (*it)->use(*this);

    if (removeAfterUse) {
        if (it->get() == equippedWeapon) {
            equippedWeapon = nullptr;
        }
        inventory.erase(it);
    }

    return true;
}
