//
// Created by SUTI0007 on 2026-03-18.
//

#include "Weapon.h"
#include"Player.h"
#include <iostream>

using namespace std;

Weapon::Weapon(const std::string& name, int bonus)
    : Item(name), attackBonus(bonus){}

int Weapon::bonus() const{
  return attackBonus;
  }

void Weapon::use(Player& player){
  player.equip(name());
}