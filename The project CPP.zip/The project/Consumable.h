//
// Created by SUTI0007 on 2026-03-18.
//

#ifndef CONSUMABLE_H
#define CONSUMABLE_H
#include<iostream>
#include <string>

#include "Item.h"

class Player;

using namespace std;
//Consumable is an item, heals the player when used
//no longer in inventory after it's use..see more in Player::useItem()

class Consumable : public Item {
  private:
  int healAmount;

  public:
    Consumable(const string& name, int heal);
    int healing()const;
    void use(Player& player) override;
};



#endif //CONSUMABLE_H
