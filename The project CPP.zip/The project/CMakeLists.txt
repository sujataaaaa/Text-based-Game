cmake_minimum_required(VERSION 3.16)

project(HotelCaliforniaRPG LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_executable(HotelCaliforniaRPG
        main.cpp
        Game.cpp
        IIO.cpp
        Item.cpp
        Player.cpp
        Enemy.cpp
        Room.cpp
        Weapon.cpp
        Consumable.cpp
        Key.cpp
)
