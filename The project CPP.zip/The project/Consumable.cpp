//
// Created by SUTI0007 on 2026-03-18.
//

#include "Consumable.h"
#include "Player.h"
#include <string>

using namespace std;

Consumable::Consumable(const string& name, int heal)
    : Item(name), healAmount(heal){}

int Consumable::healing() const{
  return healAmount;
}

void Consumable::use(Player& player) {
  player.heal(healAmount);
  }